chrome.alarms.create("clearAllDataAlarm", {
  periodInMinutes: 0.25 // 15 seconds
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "clearAllDataAlarm") {
    chrome.storage.local.get("enabled", (data) => {
      if (data.enabled ?? true) {
        chrome.browsingData.remove({ since: 0 }, {
          appcache: true,
          cache: true,
          cacheStorage: true,
          cookies: true,
          downloads: true,
          fileSystems: true,
          formData: true,
          history: true,
          indexedDB: true,
          localStorage: true,
          pluginData: true,
          passwords: true,
          serviceWorkers: true,
          webSQL: true
        }, () => {
          console.log("🔥 Browsing data nuked at", new Date().toLocaleTimeString());
        });
      } else {
        console.log("⏸ Auto Clear is disabled.");
      }
    });
  }
});
