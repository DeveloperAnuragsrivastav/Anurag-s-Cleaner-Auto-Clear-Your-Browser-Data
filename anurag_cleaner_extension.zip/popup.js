const btn = document.getElementById("toggleBtn");

chrome.storage.local.get("enabled", (data) => {
  let enabled = data.enabled ?? true;
  updateButton(enabled);

  btn.onclick = () => {
    enabled = !enabled;
    chrome.storage.local.set({ enabled });
    updateButton(enabled);
  };
});

function updateButton(enabled) {
  btn.textContent = enabled ? "Turn OFF Auto Clear" : "Turn ON Auto Clear";
  btn.classList.toggle("off", !enabled);
}
